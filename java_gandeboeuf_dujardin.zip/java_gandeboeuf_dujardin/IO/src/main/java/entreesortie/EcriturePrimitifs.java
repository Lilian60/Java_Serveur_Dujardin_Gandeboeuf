package entreesortie;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.sql.SQLOutput;

public class EcriturePrimitifs {
    /*
    DataOutputStream dos = null;

    try{
        dos = new DataOutputStream(
            new BufferedOutputStream(
                new FileOutputStream(

                )
            )
        )
    }
    catch{

    }







    try{
        dos.writeInt(1234);
        dos.writeDouble(3.14);
        System.out.println("");
    }
    */
}
