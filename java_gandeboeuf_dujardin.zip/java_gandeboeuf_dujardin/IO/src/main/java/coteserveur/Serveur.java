package coteserveur;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Serveur {
    public static void main(String[] args) {
        //debut db


        String nomDuDriverJdbcPourLeSGBD="com.mysql.cj.jdbc.Driver";


        String urlBD_MySQL="jdbc:mysql://localhost:3306/mabd";  //connexion a la base
        try{

            Class.forName(nomDuDriverJdbcPourLeSGBD);
            System.out.println("Chargement du Driver JDBC : OK");
        }catch (ClassNotFoundException e){
            e.printStackTrace();
            System.exit(-1);
        }
        Connection maCo=null;
        Statement stmt = null;
        try{
            maCo=

                    DriverManager.getConnection(
                            urlBD_MySQL,
                            "root",
                            "root"
                    );

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        try{
            stmt = maCo.createStatement(); //le statement permet d'envoyer le sql
        }catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        //fin db

        boolean needExit = false; //variable pour casser la boucle





        ServerSocket monServerSocket = null;

        try{
            monServerSocket = new ServerSocket(1234); //on ouvre le serveur
            System.out.println("Creation du serveur socket : OK");
        } catch (IOException e){
            e.printStackTrace();
            System.exit(-1);
        }

        Socket maSocket = null;
        try {
            maSocket = monServerSocket.accept(); //nouveau client
            System.out.println("Connexion d'un client");
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(-2);
        }

        while(!needExit){
            InputStream monInputStream = null;
            try {
                monInputStream = maSocket.getInputStream(); //on prend les donnees qui arrive
                System.out.println("Flux entrant obtenu");
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(-3);
            }

            BufferedInputStream bis = new BufferedInputStream(monInputStream);

            DataInputStream dis = new DataInputStream(bis);
            try {
                String typeRequete = (dis.readUTF()).replace("\n", "").replace("\r", ""); //on recupere le type
                ArrayList<String> parametresASauvegarder = new ArrayList<String>(); //pour stocker les parametres
                String sqlToAdd = "";



                if(typeRequete.equals("livres")){//pour les livres
                    for (int i = 0; i < 4; i++){
                        parametresASauvegarder.add((dis.readUTF()).replace("\n", "").replace("\r", "").replace("'","\\'"));
                    }
                    sqlToAdd = "INSERT INTO " + typeRequete + " (titre, resume, editeur, auteur) VALUES ('" + parametresASauvegarder.get(0) + "', '" + parametresASauvegarder.get(1) +"', '" + parametresASauvegarder.get(2) + "', '" + parametresASauvegarder.get(3) + "');";
                }

                else if(typeRequete.equals("lecteurs")){//pour les lecteurs
                    for (int i = 0; i < 5; i++){
                        parametresASauvegarder.add((dis.readUTF()).replace("\n", "").replace("\r", ""));
                    }
                    sqlToAdd = "INSERT INTO " + typeRequete + " (nom, prenom, dernierLivrePris, mail, telephone) VALUES ('" + parametresASauvegarder.get(0) + "', '" + parametresASauvegarder.get(1) +"', '" + parametresASauvegarder.get(2) + "', '" + parametresASauvegarder.get(3) + "', '" + parametresASauvegarder.get(4) + "');";
                }
                else if(typeRequete.equals("quitter")){ //demande de fin de connexion
                    System.out.println(typeRequete);
                    needExit = true; //pour etre sur de casser la boucle while
                    try{dis.close();}//on ferme dis
                    catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    break;//plus aucun code n'est execute dans cette boucle
                }

                else {
                    System.out.println("Erreur le type renseignee n'existe pas");//mauvais premier mot
                }

                System.out.println("SQL = " + sqlToAdd);//pour le debuguage
                try{
                    stmt.executeUpdate(sqlToAdd);//on execute le sql
                }catch (SQLException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
                System.exit(-4);
            }
        }


        try {
            System.out.println("Fin bonne journee");//message de fin
            maSocket.close();
            monServerSocket.close();//on ferme le socker
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}