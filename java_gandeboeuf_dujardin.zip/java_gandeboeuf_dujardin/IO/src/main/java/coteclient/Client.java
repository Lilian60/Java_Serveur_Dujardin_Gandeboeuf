package coteclient;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Socket maSocket = null;
        try {
            maSocket = new Socket("localhost",1234); // connexion sur le port 1234
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        OutputStream monOutputStream = null;
        try {
            monOutputStream = maSocket.getOutputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        BufferedOutputStream bos = new BufferedOutputStream(monOutputStream);
        DataOutputStream dos = new DataOutputStream(bos);

        String userValue = "";
        Scanner sc= new Scanner(System.in); //scanner, permet de recuperer la valeur utilisateur
        String[] paramLivres = {"Titre", "Resume", "Auteur", "Editeur"}; //permet d'afficher les commandes proprement
        String[] paramLecteurs = {"Nom", "Prenom", "Dernier livre pris", "Email", "Telephone"};

        System.out.println("Bonjour, que souhaitez-vous faire ?\nFaites 'help' pour obtenir la liste des commandes disponibles"); //phrase affiché qu'une fois

        while (!userValue.equals("quit")){ //boucle jusqu'à que l'utilisateur tape quit
            System.out.print("dujgansys> ");
            userValue = sc.nextLine();//recupere ce que l'utilisateur à taper

            if (userValue.equals("help")){ //affiche les commandes
                System.out.println("set (livre|lecteur) - permet d'envoyer un livre ou un lecteur");
                System.out.println("help - permet de visualiser toutes les commandes disponibles");
                System.out.println("informations - afficher des informations sur le projet");
                System.out.println("quit - permet de quitter le programme");
            }

            else if (userValue.startsWith("set ")){//permet d'envoyer les donnees
                String param1 = userValue.substring(4, userValue.length()); //on retire 'set '
                if (param1.equals("livre")){//si c'est un livre on envoie au bon endroit
                    System.out.println("Saisie d'un livre");
                    try{
                        dos.writeUTF("livres");
                        for (int i = 0; i < paramLivres.length; i++){
                            System.out.print(paramLivres[i] + " : "); //permet le format titre :, avec le tableau plus haut
                            dos.writeUTF(sc.nextLine());
                        }
                        dos.flush();//vide le dos, evite des bugs
                        System.out.println("Donnees envoyees");//confirmation
                    }catch(IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                else if(param1.equals("lecteur")){
                    System.out.println("Saisie d'un lecteur");
                    try{
                        dos.writeUTF("lecteurs"); //pareil pour les lecteurs
                        for (int i = 0; i < paramLecteurs.length; i++){
                            System.out.print(paramLecteurs[i] + " : ");
                            dos.writeUTF(sc.nextLine());
                        }
                        dos.flush();
                        System.out.println("Donnees envoyees");
                    }catch(IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                else{
                    System.out.println("Erreur de parametre merci de recommencer");//une fois le set retire, on regarde ce qu'il reste
                }
            }

            else if (userValue.startsWith("quit")){ //pour donner une confirmation
                System.out.println("Demande d'arret saisie, bonne journee");
            }

            else if (userValue.equals("informations")){ //pour les infos
                System.out.println("Projet realise par Dujardin Julien et Lilian Gandeboeuf\nIl faut d'abord lancer la partie serveur avant la partie client\nLa commande quit permet de fermer les 2 parties d'un seul coup\nMerci pour votre attention");
            }

            else{//si la commande ne sert a rien
                System.out.println("Commande errone ou incomplete, faites 'help' pour obtenir les commandes disponibles");
            }
        }

        try {
            dos.writeUTF("quitter"); //ordonne au serveur de s'arreter
            dos.close();
            maSocket.close(); //fermeture de la connexion
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
